#!/usr/bin/env bash
set -euo pipefail

# run.sh - full pipeline runner (edit parameters at top)
CLASSES_FILE=${CLASSES_FILE:-classes.txt}
OUT_DIR=${OUT_DIR:-raw}
DATASET_DIR=${DATASET_DIR:-dataset}
PER_CLASS=${PER_CLASS:-150}

# 1) Setup environment
./Setup.sh
source venv_icono/bin/activate

# 2) Download images
python download-images.py --classes-file ${CLASSES_FILE} --out-dir ${OUT_DIR} --per-class ${PER_CLASS}

# 3) (Optional) Preprocess & annotate - if you have a script or use labelImg manually
# python preprocess_and_annotate.py --in-dir ${OUT_DIR} --out-dir ${DATASET_DIR}

# 4) Sort into ImageFolder and YOLO formats (requires annotations.csv)
# python sort.py --csv annotations.csv --images-dir ${DATASET_DIR} --out-dir ${DATASET_DIR}/sorted --make-yolo

# 5) Train models (classification and detection)
python train-model_part1.py && python train-model_part2.py && python train-model_part3.py
# For detection, prepare data.yaml and run:
# python train-model_part3.py --mode detection --data-yaml data.yaml --epochs 60 --imgsz 640 --batch-size 16

# 6) Inference example (update paths accordingly)
# python inference.py --model-cls models/mobilenetv3_best.pth --model-det runs/detect/exp/weights/best.pt --image examples/test.jpg

echo "Pipeline complete (or reached the scripted steps)."
