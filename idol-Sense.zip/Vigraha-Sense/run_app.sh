#!/bin/bash

echo "=============================="
echo " Starting Iconography Chatbot "
echo "=============================="

# Create required directories if missing
echo "[✓] Ensuring required directories exist..."
mkdir -p dataset
mkdir -p raw
mkdir -p models
mkdir -p runs
mkdir -p uploads

# Create virtual environment if missing
if [ ! -d "venv_icono" ]; then
    echo "[!] Virtual environment not found. Creating..."
    python3 -m venv venv_icono
fi

# Activate virtual environment
echo "[✓] Activating venv_icono..."
source venv_icono/bin/activate

# Install/update dependencies
if [ -f "requirements.txt" ]; then
    echo "[✓] Installing/Updating Python dependencies..."
    pip install --upgrade pip
    pip install -r requirements.txt
else
    echo "[!] requirements.txt not found! Cannot install dependencies."
fi

# Verify classifier model path
export CLS_MODEL="models/mobilenetv3_best.pth"
export DET_MODEL="runs/detect/exp/weights/best.pt"
export CLASSES_FILE="classes.py"

# Notify about model presence
if [ -f "$CLS_MODEL" ]; then
    echo "[✓] Classifier found: $CLS_MODEL"
else
    echo "[!] Classifier NOT found — once you train the model, place checkpoint in: $CLS_MODEL"
fi

if [ -f "$DET_MODEL" ]; then
    echo "[✓] Detector found: $DET_MODEL"
else
    echo "[!] Detector NOT found — YOLO detection will be disabled."
fi

echo "[✓] Starting Flask chatbot..."
echo "    Open http://localhost:5000 in your browser"
echo

python3 app.py

