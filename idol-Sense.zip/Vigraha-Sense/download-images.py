#!/usr/bin/env python3
"""
download-images.py
Safe + compliant downloader for:
 - Wikimedia Commons
 - The MET Museum Open Access API

Features:
 - Proper User-Agent (required by Wikimedia!)
 - Retry system
 - Backoff wait
 - License filtering (public domain + CC allowed)
 - Saves raw images to raw/<class>/
 - Logs provenance to provenance.csv

Usage:
    python download-images.py --classes-file classes.txt --out-dir raw --per-class 150
"""

import argparse
import csv
import os
import time
from pathlib import Path
from urllib.parse import unquote

import requests
from PIL import Image
from io import BytesIO
from tqdm import tqdm

# --------------------------------------------------------
# REQUIRED USER-AGENT (Wikimedia blocks requests without this)
# --------------------------------------------------------
HEADERS = {
    "User-Agent": "IconographyResearchBot/1.0 (email: research@example.com)"
}

# Wikimedia API endpoint
WIKI_API = "https://commons.wikimedia.org/w/api.php"

# MET Museum API endpoints
MET_SEARCH = "https://collectionapi.metmuseum.org/public/collection/v1/search"
MET_OBJECT = "https://collectionapi.metmuseum.org/public/collection/v1/objects/"

# Allowed licenses (simple match)
ALLOWED_LICENSE_KEYWORDS = [
    "public domain",
    "cc-by",
    "cc-by-sa",
    "creative commons"
]

# --------------------------------------------------------
# Helper utilities
# --------------------------------------------------------

def slugify(text: str) -> str:
    return ''.join(c if c.isalnum() else '_' for c in text.lower())


def ensure_dir(path: Path):
    path.mkdir(parents=True, exist_ok=True)


def is_license_allowed(license_string: str) -> bool:
    if not license_string:
        return False
    l = license_string.lower()
    return any(k in l for k in ALLOWED_LICENSE_KEYWORDS)


def save_image_bytes(img_bytes: bytes, path: Path):
    """Save image bytes to disk."""
    ensure_dir(path.parent)
    with open(path, "wb") as f:
        f.write(img_bytes)


def safe_request(session, url, params=None, stream=False, retries=3):
    """Retry wrapper around requests.get"""
    for attempt in range(retries):
        try:
            r = session.get(
                url,
                params=params,
                headers=HEADERS,
                timeout=30,
                stream=stream
            )
            r.raise_for_status()
            return r
        except Exception:
            if attempt == retries - 1:
                return None
            time.sleep(1 + attempt * 2)  # exponential backoff
    return None


# --------------------------------------------------------
# Wikimedia Commons Downloader
# --------------------------------------------------------

def download_wikimedia_images(class_name: str, limit: int):
    """
    Searches:
      1) Category:ClassName
      2) Text search fallback
    Downloads CC/Public Domain images only.
    """

    results = []
    session = requests.Session()

    # First attempt Category search
    params = {
        "action": "query",
        "list": "categorymembers",
        "cmtitle": f"Category:{class_name}",
        "cmlimit": min(limit, 500),
        "format": "json",
    }

    r = safe_request(session, WIKI_API, params=params)
    if r is None:
        print("Wikimedia: category search failed.")
        members = []
    else:
        data = r.json()
        members = data.get("query", {}).get("categorymembers", [])

    # If category empty, fallback to text search
    if not members:
        params = {
            "action": "query",
            "list": "search",
            "srsearch": class_name,
            "srlimit": min(limit, 50),
            "format": "json",
        }
        r = safe_request(session, WIKI_API, params=params)
        if r is None:
            print("Wikimedia: text search failed.")
            return []
        data = r.json()
        members = data.get("query", {}).get("search", [])

    count = 0
    for item in members:
        title = item.get("title")
        if not title or not title.lower().startswith("file:"):
            continue

        # Get image info
        params = {
            "action": "query",
            "prop": "imageinfo|categories",
            "titles": title,
            "iiprop": "url|extmetadata|size",
            "format": "json",
        }
        r = safe_request(session, WIKI_API, params=params)
        if r is None:
            continue

        pages = r.json().get("query", {}).get("pages", {})
        if not pages:
            continue

        page = next(iter(pages.values()))
        imageinfo = page.get("imageinfo")
        if not imageinfo:
            continue

        info = imageinfo[0]
        url = info.get("url")
        extmeta = info.get("extmetadata", {})
        license_short = extmeta.get("LicenseShortName", {}).get("value", "")
        license_url = extmeta.get("LicenseUrl", {}).get("value", "")

        license_combined = (license_short or license_url)
        if not is_license_allowed(license_combined):
            continue

        # Download actual image
        r_img = safe_request(session, url)
        if r_img is None:
            continue

        try:
            img_bytes = r_img.content
            img = Image.open(BytesIO(img_bytes))
            img.verify()  # verify correctness
        except Exception:
            continue

        results.append({
            "bytes": img_bytes,
            "url": url,
            "license": license_combined,
            "source": "wikimedia",
        })

        count += 1
        if count >= limit:
            break

        time.sleep(0.2)  # polite delay

    return results


# --------------------------------------------------------
# MET Museum Downloader (Public Domain Only)
# --------------------------------------------------------

def download_met_images(class_name: str, limit: int):
    """Use MET Museum API to download public domain artworks."""
    results = []
    session = requests.Session()

    # STEP 1: search object IDs
    params = {"q": class_name}
    r = safe_request(session, MET_SEARCH, params=params)
    if r is None:
        print("MET search failed.")
        return results

    ids = r.json().get("objectIDs", []) or []
    if not ids:
        return results

    count = 0
    for oid in ids[:limit]:
        r_obj = safe_request(session, MET_OBJECT + str(oid))
        if r_obj is None:
            continue
        obj = r_obj.json()

        if not obj.get("isPublicDomain", False):
            continue

        primary_img = obj.get("primaryImage")
        if not primary_img:
            continue

        # Download the primary image
        r_img = safe_request(session, primary_img)
        if r_img is None:
            continue

        try:
            img_bytes = r_img.content
            img = Image.open(BytesIO(img_bytes))
            img.verify()
        except Exception:
            continue

        results.append({
            "bytes": img_bytes,
            "url": primary_img,
            "license": "public_domain",
            "source": "met",
        })

        count += 1
        if count >= limit:
            break

        time.sleep(0.2)

    return results


# --------------------------------------------------------
# Main Script
# --------------------------------------------------------

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--classes-file", required=True)
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--per-class", type=int, default=100)
    args = parser.parse_args()

    out_dir = Path(args.out_dir)
    ensure_dir(out_dir)

    # Load classes
    with open(args.classes_file) as f:
        classes = [line.strip() for line in f if line.strip()]

    # Log file
    prov_path = Path("provenance.csv")
    prov_exists = prov_path.exists()
    prov_f = open(prov_path, "a", newline="", encoding="utf-8")
    writer = csv.writer(prov_f)
    if not prov_exists:
        writer.writerow(["filepath", "class", "url", "license", "source"])

    # Loop through classes
    for cls in classes:
        print(f"\n=== Downloading for class: {cls} ===")
        safe_name = slugify(cls)
        class_dir = out_dir / safe_name
        ensure_dir(class_dir)

        # 1. Wikimedia
        wiki_items = download_wikimedia_images(cls, args.per_class)
        for item in tqdm(wiki_items, desc=f"Wikimedia {cls}"):
            filename = f"{safe_name}_{int(time.time()*1000)}.jpg"
            file_path = class_dir / filename
            save_image_bytes(item["bytes"], file_path)
            writer.writerow([str(file_path), cls, item["url"], item["license"], item["source"]])

        # 2. MET Museum
        met_items = download_met_images(cls, args.per_class)
        for item in tqdm(met_items, desc=f"MET {cls}"):
            filename = f"{safe_name}_{int(time.time()*1000)}_met.jpg"
            file_path = class_dir / filename
            save_image_bytes(item["bytes"], file_path)
            writer.writerow([str(file_path), cls, item["url"], item["license"], item["source"]])

    prov_f.close()
    print("\nDownload complete. See provenance.csv.\n")


if __name__ == "__main__":
    main()

