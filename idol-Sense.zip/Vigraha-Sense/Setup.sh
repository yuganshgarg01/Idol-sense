#!/bin/bash

echo "==========================="
echo " Iconography System Setup"
echo "==========================="

# Create required directories
echo "[+] Creating project folders..."
mkdir -p dataset
mkdir -p raw
mkdir -p models
mkdir -p runs
mkdir -p uploads

# Create virtual environment
echo "[+] Creating virtual environment (venv_icono)..."
python3 -m venv venv_icono

# Activate venv
echo "[+] Activating virtual environment..."
source venv_icono/bin/activate

# Install requirements
echo "[+] Installing dependencies from requirements.txt..."
pip install --upgrade pip
pip install -r requirements.txt

echo "==========================="
echo " Setup completed!"
echo "==========================="

