#!/usr/bin/env python3
"""
Clean Flask app for Iconography Chatbot

- Upload an image
- Runs classifier (MobileNetV3 checkpoint) and optional YOLOv8 detector
- Applies rule-based fusion and returns human-friendly explanation

Assumptions / defaults (edit constants below if you have different paths):
  - Classifier checkpoint: models/mobilenetv3_best.pth
  - Detector checkpoint (optional): runs/detect/exp/weights/best.pt
  - Classes file fallback: classes.py or classes.txt

Run:
  source venv_icono/bin/activate
  python3 app.py
"""

import io
import os
from pathlib import Path
from datetime import datetime
from typing import List

from flask import Flask, request, render_template_string, redirect, url_for, send_from_directory, jsonify
from PIL import Image

import torch
import torch.nn.functional as F
import timm
import torchvision.transforms as T

# Try import ultralytics YOLO (optional)
try:
    from ultralytics import YOLO
    YOLO_AVAILABLE = True
except Exception:
    YOLO_AVAILABLE = False

# ----------------------------
# Configuration (edit if needed)
# ----------------------------
CLS_MODEL_PATH = Path(os.environ.get("CLS_MODEL", "models/mobilenetv3_best.pth"))
DET_MODEL_PATH = Path(os.environ.get("DET_MODEL", "runs/detect/exp/weights/best.pt"))
CLASSES_FILE = Path(os.environ.get("CLASSES_FILE", "classes.py"))
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

# ----------------------------
# Simple HTML template
# ----------------------------
INDEX_HTML = """
<!doctype html>
<title>Iconography Chatbot</title>
<style>
body { font-family: Arial, sans-serif; max-width:900px; margin: 2rem auto; color: #222; }
header { margin-bottom: 1rem; }
.preview { max-width: 320px; max-height: 320px; border: 1px solid #ddd; padding:4px; }
.results { background:#fbfbfb; padding:1rem; border-radius:8px; margin-top:1rem; box-shadow: 0 1px 4px rgba(0,0,0,0.06); }
small.note { color:#666; }
.code { font-family: monospace; background:#f0f0f0; padding:0.2rem 0.4rem; border-radius:4px; }
footer { margin-top:1.5rem; color:#666; font-size:0.9rem; }
</style>
<header>
  <h1>Iconography Chatbot</h1>
  <p class="note">Upload a sculpture photo — the app will identify the deity/form, list iconographic features, and explain the reasoning.</p>
</header>
<form method=post enctype=multipart/form-data action="{{ url_for('analyze') }}">
  <label>Choose image: <input type=file name=image accept="image/*" required></label><br><br>
  <label>Optional note: <input type="text" name="note" placeholder="e.g., 'Which deity is this?'" style="width:60%"></label><br><br>
  <button type=submit>Analyze</button>
</form>

{% if result %}
  <div class="results">
    <h3>Result</h3>
    <div style="display:flex; gap:1rem; align-items:flex-start;">
      <div>
        <img class="preview" src="{{ result.image_url }}" alt="uploaded image"/>
      </div>
      <div style="flex:1">
        <p><strong>Final label:</strong> {{ result.final_label }}</p>
        <p><strong>Classifier:</strong> {{ result.cls_label }} (confidence: {{ '%.2f'|format(result.cls_conf) }})</p>
        <p><strong>Detected attributes:</strong></p>
        {% if result.attributes %}
          <ul>
          {% for a in result.attributes %}
            <li>{{ a.name }} — {{ '%.2f'|format(a.conf) }}</li>
          {% endfor %}
          </ul>
        {% else %}
          <p><em>No strong attribute detections</em></p>
        {% endif %}
        <p><strong>Explanation:</strong></p>
        <p>{{ result.explanation }}</p>
        <p style="font-size:0.85em; color:#666;"><strong>Trace:</strong> {{ result.trace }}</p>
      </div>
    </div>
  </div>
{% endif %}

<footer>
  Models: <span class="code">{{ cls_path }}</span>{% if det_exists %} &amp; <span class="code">{{ det_path }}</span>{% else %} (detector not loaded){% endif %} • Device: {{ device }}
</footer>
"""

# ----------------------------
# Helpers: load classes
# ----------------------------
def load_classes_from_checkpoint(ckpt_path: Path):
    try:
        ckpt = torch.load(str(ckpt_path), map_location="cpu")
        if isinstance(ckpt, dict) and "classes" in ckpt:
            classes = list(ckpt["classes"])
            return classes
    except Exception:
        pass
    return []

def load_classes_from_file(path: Path):
    if not path.exists():
        return []
    if path.suffix == ".py":
        # run the file and read CLASSES
        import runpy
        try:
            data = runpy.run_path(str(path))
            if "CLASSES" in data:
                return list(data["CLASSES"])
        except Exception:
            return []
    else:
        try:
            with open(path, "r", encoding="utf-8") as fh:
                lines = [ln.strip() for ln in fh.readlines() if ln.strip()]
                return lines
        except Exception:
            return []
    return []

# ----------------------------
# Model build / load
# ----------------------------
def build_classifier(num_classes: int, model_name: str = "mobilenetv3_large_100"):
    model = timm.create_model(model_name, pretrained=False, num_classes=num_classes)
    return model

def prepare_image(pil_img: Image.Image, input_size: int = 224):
    tf = T.Compose([
        T.Resize(int(input_size * 1.15)),
        T.CenterCrop(input_size),
        T.ToTensor(),
        T.Normalize(mean=(0.485, 0.456, 0.406),
                    std=(0.229, 0.224, 0.225)),
    ])
    return tf(pil_img).unsqueeze(0)

# ----------------------------
# Fusion rules (conservative)
# ----------------------------
def fusion_rules(classifier_name: str, classifier_conf: float, det_names: List[str], det_confs: List[float]):
    det_set = set([n.lower() for n in det_names])
    # Strong attribute overrides
    if any("boar" in n for n in det_set) or "boar_head" in det_set:
        return "varaha", "Boar head detected"
    if any("lion" in n for n in det_set) or "lion_head" in det_set or any("narasimha" in n for n in det_set):
        return "narasimha", "Lion-like attributes detected"
    if "flute" in det_set or "bansuri" in det_set:
        return "krishna_venugopala", "Flute detected (Krishna attribute)"
    shiva_inds = {"trishula", "damaru", "jata", "crescent_moon", "ganga", "third_eye"}
    if det_set & shiva_inds:
        if classifier_name.startswith("shiva_nataraja") and classifier_conf >= 0.6:
            return "shiva_nataraja", "Classifier strongly predicted Nataraja"
        return "shiva_standing", "Shiva attributes detected: " + ", ".join(sorted(det_set & shiva_inds))
    if "chakra" in det_set and "shankha" in det_set:
        return "vishnu_standing", "Chakra + Shankha detected (Vishnu)"
    if "lotus" in det_set and classifier_name.startswith("lakshmi"):
        return "lakshmi", "Lotus detected and classifier suggests Lakshmi"
    if "mouse" in det_set or "elephant" in det_set or "ganesha" in " ".join(det_set):
        return "ganesha_sitting", "Ganesha attributes detected"
    # fallback
    return classifier_name, "Fallback to classifier prediction"

# ----------------------------
# Load classes & models at startup
# ----------------------------
print("App startup: loading classes and models (this may take a few seconds)...")

# Try load classes from checkpoint first, then file fallback
CLASSES = []
if CLS_MODEL_PATH.exists():
    CLASSES = load_classes_from_checkpoint(CLS_MODEL_PATH)
if not CLASSES:
    CLASSES = load_classes_from_file(CLASSES_FILE)
if not CLASSES:
    # last-resort default
    CLASSES = ["unknown"]
print(f"Classes loaded: {len(CLASSES)}")

# Load classifier
classifier = None
try:
    classifier = build_classifier(num_classes=len(CLASSES))
    ckpt = torch.load(str(CLS_MODEL_PATH), map_location=DEVICE)
    # checkpoint may be dict with model_state_dict
    state = ckpt.get("model_state_dict", ckpt) if isinstance(ckpt, dict) else ckpt
    classifier.load_state_dict(state, strict=False)
    classifier.to(DEVICE)
    classifier.eval()
    print("Classifier loaded from:", CLS_MODEL_PATH)
except Exception as e:
    print("Warning: failed to load classifier:", e)
    classifier = None

# Load YOLO detector if available and present
yolo = None
det_exists = False
if YOLO_AVAILABLE and DET_MODEL_PATH.exists():
    try:
        yolo = YOLO(str(DET_MODEL_PATH))
        det_exists = True
        print("YOLO detector loaded from:", DET_MODEL_PATH)
    except Exception as e:
        print("Warning: failed to load YOLO detector:", e)
        yolo = None
else:
    if not YOLO_AVAILABLE:
        print("Ultralytics YOLO not installed; detector disabled.")
    elif not DET_MODEL_PATH.exists():
        print("Detection model not found at:", DET_MODEL_PATH)

# ----------------------------
# Flask app
# ----------------------------
app = Flask(__name__)

@app.route("/", methods=["GET"])
def index():
    return render_template_string(INDEX_HTML,
                                  result=None,
                                  cls_path=str(CLS_MODEL_PATH),
                                  det_path=str(DET_MODEL_PATH),
                                  det_exists=det_exists,
                                  device=str(DEVICE))

@app.route("/analyze", methods=["POST"])
def analyze():
    uploaded = request.files.get("image")
    note = request.form.get("note", "").strip()
    if not uploaded:
        return redirect(url_for("index"))
    # Save uploaded file
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    filename = f"{timestamp}_{uploaded.filename}"
    saved_path = UPLOAD_DIR / filename
    data = uploaded.read()
    with open(saved_path, "wb") as f:
        f.write(data)
    # Open as PIL
    try:
        pil_img = Image.open(io.BytesIO(data)).convert("RGB")
    except Exception as e:
        return f"Error reading image: {e}", 400

    # Classification inference
    cls_label = "unknown"
    cls_conf = 0.0
    trace = []
    try:
        if classifier is not None:
            inp = prepare_image(pil_img).to(DEVICE)
            with torch.no_grad():
                out = classifier(inp)
                # handle binary / single-output case
                if out.dim() == 1 or (out.dim() == 2 and out.shape[1] == 1):
                    prob = float(torch.sigmoid(out).cpu().numpy().ravel()[0])
                    cls_label = CLASSES[0] if CLASSES else "unknown"
                    cls_conf = prob
                else:
                    probs = F.softmax(out, dim=1)[0].cpu().numpy()
                    idx = int(probs.argmax())
                    cls_label = CLASSES[idx] if idx < len(CLASSES) else "unknown"
                    cls_conf = float(probs[idx])
            trace.append(f"classifier:{cls_label}({cls_conf:.2f})")
    except Exception as e:
        trace.append(f"classifier_error:{e}")

    # Detection inference (attributes)
    attributes = []
    det_names = []
    det_confs = []
    if yolo is not None:
        try:
            results = yolo.predict(source=str(saved_path), imgsz=640, conf=0.25, verbose=False)
            if results:
                r = results[0]
                boxes = getattr(r, "boxes", None)
                if boxes is not None:
                    try:
                        cls_ids = boxes.cls.cpu().numpy().astype(int).tolist()
                        confs = boxes.conf.cpu().numpy().tolist()
                        names = [r.names[c] if c in r.names else str(c) for c in cls_ids]
                        for n, c in zip(names, confs):
                            attributes.append({"name": n, "conf": float(c)})
                            det_names.append(n)
                            det_confs.append(float(c))
                    except Exception:
                        # some older ultralytics return different structure - ignore gracefully
                        pass
            trace.append(f"detection_count:{len(attributes)}")
        except Exception as e:
            trace.append(f"detection_error:{e}")

    # Fusion
    final_label, reasoning = fusion_rules(cls_label, cls_conf, det_names, det_confs)
    trace.append(f"fusion:{reasoning}")

    # Build explanation
    if attributes:
        attr_text = ", ".join([f"{a['name']}({a['conf']:.2f})" for a in attributes])
        explanation = f"Detected attributes: {attr_text}. "
    else:
        explanation = "No strong attribute detections. "
    explanation += f"The classifier predicted '{cls_label}' (confidence {cls_conf:.2f}). After applying iconographic rules, the final label is '{final_label}'. Reason: {reasoning}."

    result = {
        "final_label": final_label,
        "cls_label": cls_label,
        "cls_conf": cls_conf,
        "attributes": attributes,
        "explanation": explanation,
        "trace": " | ".join(trace),
        "image_url": f"/uploads/{filename}"
    }

    return render_template_string(INDEX_HTML,
                                  result=result,
                                  cls_path=str(CLS_MODEL_PATH),
                                  det_path=str(DET_MODEL_PATH),
                                  det_exists=det_exists,
                                  device=str(DEVICE))

@app.route("/uploads/<path:filename>")
def uploaded_file(filename):
    return send_from_directory(str(UPLOAD_DIR), filename)

@app.route("/api/analyze", methods=["POST"])
def api_analyze():
    if "image" not in request.files:
        return jsonify({"error": "no image provided"}), 400
    uploaded = request.files["image"]
    data = uploaded.read()
    try:
        pil_img = Image.open(io.BytesIO(data)).convert("RGB")
    except Exception as e:
        return jsonify({"error": f"invalid image: {e}"}), 400

    # save
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    filename = f"{timestamp}_{uploaded.filename}"
    saved_path = UPLOAD_DIR / filename
    with open(saved_path, "wb") as f:
        f.write(data)

    cls_label = "unknown"; cls_conf = 0.0; trace = []; attributes = []; det_names = []; det_confs = []
    # classification
    try:
        if classifier is not None:
            inp = prepare_image(pil_img).to(DEVICE)
            with torch.no_grad():
                out = classifier(inp)
                if out.dim() == 1 or (out.dim() == 2 and out.shape[1] == 1):
                    prob = float(torch.sigmoid(out).cpu().numpy().ravel()[0])
                    cls_label = CLASSES[0] if CLASSES else "unknown"
                    cls_conf = prob
                else:
                    probs = F.softmax(out, dim=1)[0].cpu().numpy()
                    idx = int(probs.argmax())
                    cls_label = CLASSES[idx] if idx < len(CLASSES) else "unknown"
                    cls_conf = float(probs[idx])
            trace.append(f"classifier:{cls_label}({cls_conf:.2f})")
    except Exception as e:
        trace.append(f"classifier_error:{e}")

    # detection
    if yolo is not None:
        try:
            results = yolo.predict(source=str(saved_path), imgsz=640, conf=0.25, verbose=False)
            if results:
                r = results[0]
                boxes = getattr(r, "boxes", None)
                if boxes is not None:
                    cls_ids = boxes.cls.cpu().numpy().astype(int).tolist()
                    confs = boxes.conf.cpu().numpy().tolist()
                    names = [r.names[c] if c in r.names else str(c) for c in cls_ids]
                    for n, c in zip(names, confs):
                        attributes.append({"name": n, "conf": float(c)})
                        det_names.append(n); det_confs.append(float(c))
            trace.append(f"detection_count:{len(attributes)}")
        except Exception as e:
            trace.append(f"detection_error:{e}")

    final_label, reasoning = fusion_rules(cls_label, cls_conf, det_names, det_confs)
    trace.append(f"fusion:{reasoning}")

    explanation = {
        "detected_attributes": attributes,
        "classifier_prediction": {"label": cls_label, "conf": cls_conf},
        "final_label": final_label,
        "reasoning": reasoning,
        "trace": trace
    }
    return jsonify(explanation)

if __name__ == "__main__":
    print("Starting Flask app...")
    app.run(host="0.0.0.0", port=5000)

