#!/usr/bin/env python3
"""train-model_part1.py
Part 1/3: imports, utilities, dataset, model builder
"""

import argparse
import os
import sys
import time
from pathlib import Path
from typing import Optional, Tuple, List

import numpy as np
from tqdm import tqdm

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms, datasets
import torchvision
import timm

# Optional multi-label support
import pandas as pd
from sklearn.metrics import f1_score, accuracy_score

# Ultralytics YOLO API (used later by detection part)
try:
    from ultralytics import YOLO
    ULTRALYTICS_AVAILABLE = True
except Exception:
    ULTRALYTICS_AVAILABLE = False


# ---------- Utilities ----------
def is_cuda_available():
    return torch.cuda.is_available()


def get_device(prefer_gpu=True):
    if prefer_gpu and torch.cuda.is_available():
        return torch.device('cuda')
    return torch.device('cpu')


def save_checkpoint(state, path: Path):
    torch.save(state, str(path))


def load_checkpoint(model, path: Path, device):
    ckpt = torch.load(str(path), map_location=device)
    model.load_state_dict(ckpt['model_state_dict'])
    return ckpt


# ---------- Multi-label Dataset (CSV) ----------
class MultiLabelDataset(Dataset):
    """
    CSV format (example):
    filename,label1;label2;...
    Images located relative to img_root.
    """

    def __init__(self, csv_file: str, img_root: str, classes: List[str], transforms=None, delim=';'):
        self.df = pd.read_csv(csv_file)
        self.img_root = Path(img_root)
        self.transforms = transforms
        self.classes = classes
        self.class_to_idx = {c: i for i, c in enumerate(classes)}
        self.delim = delim

        # ensure columns
        if 'filename' not in self.df.columns or 'labels' not in self.df.columns:
            raise ValueError("CSV must have columns: filename, labels (semicolon-separated)")

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        fn = str(self.img_root / row['filename'])
        img = torchvision.io.read_image(fn)  # returns CxHxW uint8 tensor
        img = img.float() / 255.0
        # convert to PIL-like for transforms if they expect PIL
        img = torchvision.transforms.functional.to_pil_image(img)

        if self.transforms:
            img = self.transforms(img)
        labels_raw = str(row['labels'])
        labels = [l.strip() for l in labels_raw.split(self.delim) if l.strip()]
        target = torch.zeros(len(self.classes), dtype=torch.float32)
        for lab in labels:
            if lab in self.class_to_idx:
                target[self.class_to_idx[lab]] = 1.0
        return img, target


# ---------- Training: Classification (MobileNetV3) ----------
def build_classification_model(num_classes: int, pretrained=True, model_name='mobilenetv3_large_100'):
    model = timm.create_model(model_name, pretrained=pretrained, num_classes=num_classes)
    return model
#!/usr/bin/env python3
"""train-model_part2.py
Part 2/3: classification training routine
(Requires part1 to have been loaded first when concatenated)
"""

def train_classification(args):
    """
    Train MobileNetV3 classification (single-label ImageFolder or multi-label CSV)
    """
    device = get_device(prefer_gpu=not args.cpu)
    print(f"[classification] device: {device}")

    # Transforms
    input_size = args.input_size or 224
    train_tf = transforms.Compose([
        transforms.RandomResizedCrop(input_size),
        transforms.RandomHorizontalFlip(),
        transforms.ColorJitter(0.1, 0.1, 0.1, 0.05),
        transforms.ToTensor(),
        transforms.Normalize(mean=(0.485, 0.456, 0.406),
                             std=(0.229, 0.224, 0.225)),
    ])
    val_tf = transforms.Compose([
        transforms.Resize(int(input_size * 1.15)),
        transforms.CenterCrop(input_size),
        transforms.ToTensor(),
        transforms.Normalize(mean=(0.485, 0.456, 0.406),
                             std=(0.229, 0.224, 0.225)),
    ])

    # Dataset selection
    if args.multi_label:
        if not args.data_csv or not args.img_root:
            raise ValueError("--data-csv and --img-root are required for multi-label mode")
        classes = args.classes if args.classes else []
        if not classes:
            raise ValueError("Provide class list via --classes or a classes file when using multi-label")
        train_ds = MultiLabelDataset(args.data_csv, args.img_root, classes, transforms=train_tf)
        # For validation, naive split or separate CSV could be used
        # Here we'll do a train/val split
        n = len(train_ds)
        valn = max(int(0.15 * n), 1)
        train_ds, val_ds = torch.utils.data.random_split(train_ds, [n - valn, valn])
        num_classes = len(classes)
    else:
        # ImageFolder expects structure: data_dir/<class>/*.jpg
        if not args.data_dir:
            raise ValueError("--data-dir is required for ImageFolder classification")
        full_dataset = datasets.ImageFolder(args.data_dir, transform=train_tf)
        class_to_idx = full_dataset.class_to_idx
        classes = [None] * len(class_to_idx)
        for k, v in class_to_idx.items():
            classes[v] = k
        num_classes = len(classes)
        # split
        n = len(full_dataset)
        valn = max(int(0.15 * n), 1)
        train_ds, val_ds = torch.utils.data.random_split(full_dataset, [n - valn, valn])
        # Replace val transforms
        val_ds.dataset.transform = val_tf

    print(f"[classification] classes: {num_classes}; train size: {len(train_ds)}; val size: {len(val_ds)}")

    # Model
    model = build_classification_model(num_classes=num_classes, pretrained=not args.no_pretrained, model_name=args.model_name)
    model.to(device)

    # Loss and optimizer
    if args.multi_label:
        criterion = nn.BCEWithLogitsLoss()
    else:
        criterion = nn.CrossEntropyLoss()

    optimizer = optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(1, args.epochs))

    # DataLoaders
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers, pin_memory=True)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True)

    best_metric = -1.0
    best_path = Path(args.output_dir) / "mobilenetv3_best.pth"
    os.makedirs(args.output_dir, exist_ok=True)

    scaler = torch.cuda.amp.GradScaler(enabled=(device.type == 'cuda' and args.amp))

    for epoch in range(1, args.epochs + 1):
        model.train()
        running_loss = 0.0
        bar = tqdm(train_loader, desc=f"[cls] Epoch {epoch}/{args.epochs}", unit="it")
        for imgs, targets in bar:
            imgs = imgs.to(device)
            targets = targets.to(device) if args.multi_label else targets.to(device)

            optimizer.zero_grad()
            with torch.cuda.amp.autocast(enabled=(device.type == 'cuda' and args.amp)):
                outputs = model(imgs)
                if args.multi_label:
                    loss = criterion(outputs, targets)
                else:
                    loss = criterion(outputs, targets)
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            running_loss += loss.item() * imgs.size(0)
            bar.set_postfix(loss=running_loss / ((bar.n + 1) * args.batch_size))

        scheduler.step()

        # Validation
        model.eval()
        all_preds = []
        all_targets = []
        val_loss = 0.0
        with torch.no_grad():
            for imgs, targets in val_loader:
                imgs = imgs.to(device)
                targets = targets.to(device) if args.multi_label else targets.to(device)
                outputs = model(imgs)
                if args.multi_label:
                    loss = criterion(outputs, targets)
                    preds = torch.sigmoid(outputs).cpu().numpy()
                    all_preds.append(preds)
                    all_targets.append(targets.cpu().numpy())
                else:
                    loss = criterion(outputs, targets)
                    preds = torch.softmax(outputs, dim=1).argmax(dim=1).cpu().numpy()
                    all_preds.append(preds)
                    all_targets.append(targets.cpu().numpy())
                val_loss += loss.item() * imgs.size(0)

        # metrics
        if args.multi_label:
            y_pred = np.vstack(all_preds)
            y_true = np.vstack(all_targets)
            # threshold 0.5 for f1
            y_pred_bin = (y_pred >= 0.5).astype(int)
            f1 = f1_score(y_true, y_pred_bin, average='macro', zero_division=0)
            metric = f1
            print(f"[cls] Epoch {epoch} val_loss={val_loss/len(val_loader.dataset):.4f} f1_macro={f1:.4f}")
        else:
            y_pred = np.concatenate(all_preds)
            y_true = np.concatenate(all_targets)
            acc = accuracy_score(y_true, y_pred)
            metric = acc
            print(f"[cls] Epoch {epoch} val_loss={val_loss/len(val_loader.dataset):.4f} acc={acc:.4f}")

        # checkpoint
        if metric > best_metric:
            print(f"[cls] New best metric: {metric:.4f} (prev {best_metric:.4f}). Saving checkpoint to {best_path}")
            best_metric = metric
            save_checkpoint({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'metric': metric,
                'classes': classes
            }, best_path)

    print("[classification] Training completed. Best metric:", best_metric)
    return best_path
#!/usr/bin/env python3
"""train-model_part3.py
Part 3/3: detection training, argument parsing and main()
(Depends on parts 1 & 2)
"""

def train_detection(args):
    if not ULTRALYTICS_AVAILABLE:
        raise RuntimeError("Ultralytics package not available. Install via `pip install ultralytics`")

    device = 'cuda' if is_cuda_available() and not args.cpu else 'cpu'
    print(f"[detection] device: {device}")

    # Ensure data_yaml is provided
    if not args.data_yaml:
        raise ValueError("--data-yaml is required for detection mode (YOLOv8 data file)")

    # Use YOLO API to train
    model_name = args.yolo_model or "yolov8n.pt"
    print(f"[detection] Starting YOLOv8 training with model: {model_name}")
    model = YOLO(model_name)

    # Build kwargs
    train_kwargs = dict(
        data=args.data_yaml,
        epochs=args.epochs,
        imgsz=args.imgsz,
        batch=args.batch_size,
        device=device,
        save=True,
        project=args.yolo_project or "yolov8_runs",
        name=args.yolo_run_name or "exp"
    )

    # Start training
    res = model.train(**train_kwargs)
    print(f"[detection] YOLO training returned: {res}")
    # best weights path (Ultralytics writes to runs/...)
    return res


# ---------- Argument parsing ----------
def parse_args():
    p = argparse.ArgumentParser(description="Train classification (MobileNetV3) and detection (YOLOv8)")
    p.add_argument('--mode', choices=('classification', 'detection', 'both'), default='both',
                   help='Which models to train')
    # classification args
    p.add_argument('--data-dir', type=str, help='ImageFolder root (for classification) e.g. dataset/sorted')
    p.add_argument('--data-csv', type=str, help='CSV for multi-label classification (filename,labels)')
    p.add_argument('--img-root', type=str, help='Root dir for images referenced in data-csv')
    p.add_argument('--multi-label', action='store_true', help='If set, classification uses CSV multi-label mode')
    p.add_argument('--classes', nargs='*', help='List of classes (for multi-label). If omitted, provide via classes file)')
    p.add_argument('--model-name', type=str, default='mobilenetv3_large_100', help='timm model name')
    p.add_argument('--no-pretrained', action='store_true', help='Do not use pretrained ImageNet weights')
    # detection args
    p.add_argument('--data-yaml', type=str, help='YOLOv8 data.yaml path (for detection)')
    p.add_argument('--yolo-model', type=str, default='yolov8n.pt', help='YOLOv8 base model checkpoint')
    p.add_argument('--yolo-project', type=str, default='yolov8_runs', help='YOLOv8 project dir')
    p.add_argument('--yolo-run-name', type=str, default='exp', help='YOLOv8 run name')
    # common args
    p.add_argument('--epochs', type=int, default=30)
    p.add_argument('--batch-size', type=int, default=32)
    p.add_argument('--lr', type=float, default=1e-3)
    p.add_argument('--weight-decay', type=float, default=1e-4)
    p.add_argument('--input-size', type=int, default=224)
    p.add_argument('--imgsz', type=int, default=640, help='YOLO image size')
    p.add_argument('--num-workers', type=int, default=4)
    p.add_argument('--output-dir', type=str, default='models', help='Where to save classification weights')
    p.add_argument('--amp', action='store_true', help='Enable mixed precision training for classification (if GPU available)')
    p.add_argument('--cpu', action='store_true', help='Force CPU (no CUDA)')
    p.add_argument('--seed', type=int, default=42)
    return p.parse_args()


# ---------- Main ----------
def main():
    args = parse_args()
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    os.makedirs(args.output_dir, exist_ok=True)

    if args.mode in ('classification', 'both'):
        print("=== Running classification training ===")
        try:
            cls_ckpt = train_classification(args)
            print(f"[main] Classification checkpoint saved at: {cls_ckpt}")
        except Exception as e:
            print("[main] Classification training failed:", e)
            raise

    if args.mode in ('detection', 'both'):
        print("=== Running detection training ===")
        try:
            det_res = train_detection(args)
            print(f"[main] Detection training completed. Result: {det_res}")
        except Exception as e:
            print("[main] Detection training failed:", e)
            raise

    print("All requested training finished.")


if __name__ == '__main__':
    main()
