# classes.py
# Hard-coded class ontology and short iconography descriptions used as label ontology

CLASSES = [
    'shiva_standing',
    'shiva_nataraja',
    'shiva_lingam',
    'ardhanarishvara',
    'bhairava',
    'vishnu_standing',
    'varaha',
    'narasimha',
    'rama',
    'krishna_venugopala',
    'ganesha_standing',
    'ganesha_sitting',
    'durga_mahishasuramardini',
    'lakshmi',
    'saraswati',
    'parvati',
    'surya',
    'hanuman',
    'nandi',
    'garuda'
]

# Descriptions: used for metadata, annotation guidance and rule-based fusion
DESCRIPTIONS = {
    'shiva_standing': {
        'heads': 1,
        'arms': [2,4],
        'attributes': ['trishula','damaru','crescent_moon','jata','ganga'],
        'vahana': 'nandi',
        'note': 'Shiva often shown with trident, matted hair (jata), Ganga emerging, crescent moon on head, Nandi nearby.'
    },
    'shiva_nataraja': {
        'pose': 'dancing',
        'attributes': ['damaru','agni','abhramsha_prabha'],
        'note': 'Shiva as Nataraja: dancing within a ring of fire, apasmara (dwarf) underfoot, damaru & fire in hands.'
    },
    'shiva_lingam': {
        'form': 'lingam',
        'note': 'Aniconic cylindrical form (lingam) on a yoni base. No arms; may have a sculpted face (mukhalingam) in some cases.'
    },
    'ardhanarishvara': {
        'description': 'Composite half-male (Shiva) and half-female (Parvati) figure; split attire & attributes on halves.',
        'note': 'Left typically female with breast & sari; right male with jata and trishula attributes.'
    },
    'bhairava': {
        'features': ['fierce_expression','skulls','danda','kapaala'],
        'note': 'Fierce form of Shiva, often with skulls, holding a trident or staff, sometimes with a dog vehicle.'
    },
    'vishnu_standing': {
        'heads': 1,
        'arms': 4,
        'attributes': ['shankha','chakra','gada','padma'],
        'crown': 'kiritamukuta',
        'vahana': 'garuda',
        'note': 'Vishnu typically has four arms holding conch (shankha), discus (chakra), mace (gada), and lotus (padma).'
    },
    'varaha': {
        'head': 'boar',
        'attributes': ['lift_bhudevi','chakra','shankha'],
        'note': 'Boar-headed avatar of Vishnu often lifting the earth (Bhudevi) from the ocean.'
    },
    'narasimha': {
        'head': 'lion',
        'attributes': ['hiraṇyakaśipu_scene','chakra','shankha','ferocious_expression'],
        'note': 'Man-lion form of Vishnu, shown tearing the demon Hiranyakashipu or in seated ferocious posture.'
    },
    'rama': {
        'attributes': ['bow','arrow','kodanda'],
        'note': 'Rama (avatar of Vishnu) often shown with bow (Kodanda) and arrow, upright heroic posture.'
    },
    'krishna_venugopala': {
        'attributes': ['flute','peacock_feather','butter'],
        'note': 'Krishna as Venugopala: standing playing the flute, often shown with cow/herding motifs.'
    },
    'ganesha_standing': {
        'head': 'elephant',
        'attributes': ['modaka','ankusha','pasha','broken_tusk'],
        'vahana': 'mouse',
        'note': 'Ganesha with elephant head; may hold a sweet (modaka), axe (ankusha), noose (pasha), and have a mouse as vahana.'
    },
    'ganesha_sitting': {
        'pose': 'seated',
        'attributes': ['modaka','ankusha','pasha','broken_tusk'],
        'note': 'Seated Ganesha often on a small throne or lotus, legs folded, with typical attributes.'
    },
    'durga_mahishasuramardini': {
        'attributes': ['lion','sword','trident','dismembered_demon','many_arms'],
        'note': 'Durga slaying the buffalo demon Mahishasura, often mounted on a lion, multiple arms with weapons.'
    },
    'lakshmi': {
        'attributes': ['lotus','coins','elephants','two_hands','varada_abhiaya'],
        'note': 'Goddess of wealth, often on a lotus with elephants; holds lotus and sometimes gold coins.'
    },
    'saraswati': {
        'attributes': ['veena','book','rosary','swan'],
        'note': 'Goddess of knowledge, shown with a veena (stringed instrument), book, and a swan.'
    },
    'parvati': {
        'attributes': ['gentle_expression','attendant_of_shiva','lotus'],
        'note': 'Consort of Shiva, often shown alongside him or with attributes of fertility and devotion.'
    },
    'surya': {
        'attributes': ['rising_sun','chariot','two_or_four_arms','lotus'],
        'note': 'Sun god typically shown riding a chariot driven by horses, often holding lotuses.'
    },
    'hanuman': {
        'attributes': ['monkey_face','gada','flying_pose','devotee_of_rama'],
        'note': 'Monkey-god and devotee of Rama, often flying or carrying mountain; may hold mace (gada).'
    },
    'nandi': {
        'form': 'bull',
        'note': 'The bull vehicle (vahana) of Shiva; often sculpted facing the Shiva shrine or as a separate seated figure.'
    },
    'garuda': {
        'form': 'bird',
        'note': 'The eagle-like vehicle of Vishnu; humanoid bird form, often shown carrying Vishnu or standing with wings.'
    }
}

ATTRIBUTE_CLASSES = [
    'trishula','damaru','shankha','chakra','gada','lotus','flute','bow','arrow',
    'third_eye','jata','crescent_moon','ganga','nandi','garuda','mouse','lion','boar_head','human_head','modaka'
]

if __name__ == '__main__':
    print('Classes loaded:', len(CLASSES))
